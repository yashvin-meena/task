from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
import stripe
from django.conf import settings
from appointments.models import Appointment
from rest_framework.permissions import IsAuthenticated
from doctors.models import Doctor
from .serializers import AccountDetailSerializer, TransactionSerializer
from .models import AccountDetail, Transaction, Payment
import time


# Stripe secret key
stripe.api_key = settings.STRIPE_SECRET_KEY

class CrateAccountView(APIView):
    def post(self, request):
        try:
            account = AccountDetail.objects.all().first()
            print('Account', account.user.first_name)

            clinic_account = stripe.Account.create(
                type="custom",
                country="AU",
                email="testuser@gmail.com",
                business_type="individual",
                capabilities={"transfers": {"requested": True}},  # Enables fund transfers
            )

            clinic_stripe_id = clinic_account.id
            print("Clinic Stripe Account ID:", clinic_stripe_id)

            stripe.Account.modify(
                clinic_stripe_id,
                individual={
                    "first_name": "Test",
                    "last_name": "User",
                    "dob": {"day": 1, "month": 1, "year": 1990},
                    "address": {
                        "line1": "123 Fake Street",
                        "city": "Sydney",
                        "state": "NSW",
                        "postal_code": "2000",
                        "country": "AU",
                    },
                    "email": "testuser@example.com",
                    "id_number": "000000000",  # Use a dummy ID number
                },
            )

            stripe.Account.modify(
                clinic_stripe_id,
                business_profile={"url": "https://yourbusiness.test"},  # Fake business URL
                tos_acceptance={
                    "date": int(time.time()),  # Current timestamp
                    "ip": "192.168.1.1"  # Fake IP address for testing
                }
            )

            stripe.Account.modify(
                clinic_stripe_id,
                capabilities={"transfers": {"requested": True}}
            )

            stripe.Account.create_external_account(
                clinic_stripe_id,
                external_account={
                    "object": "bank_account",
                    "country": "AU",
                    "currency": "AUD",
                    "account_holder_name": f"Test User",
                    "account_holder_type": "individual",
                    "routing_number": account.ifsc_code,
                    "account_number": account.account_number,
                }
            )
            account_info = stripe.Account.retrieve(clinic_stripe_id)
            print(account_info["requirements"])
            return Response("Account Created", status=status.HTTP_201_CREATED)

        except Exception as e:
            return Response(str(e), status=status.HTTP_400_BAD_REQUEST)

    def get(self,request):
        account_info = stripe.Account.retrieve("acct_1QuBzkPPCNvqJSUB")
        print(account_info["requirements"])
        print(account_info["capabilities"])
        # print(account_info["disabled_reason"])
        return Response({'message':"success"})


class StripePaymentAPIView(APIView):
    """
    Stripe payment using PaymentIntent.
    """

    def post(self, request, *args, **kwargs):
        try:
            # Get data from the request
            test_token = request.data.get('test_token')
            amount = request.data.get('amount')
            appointment_id = request.data.get('appointment_id')
            payment_method_types = request.data.get('payment_method_types')
            description = request.data.get('description')

            # Validate required fields
            if not test_token or not amount or not appointment_id or not payment_method_types:
                return Response(
                    {
                        "error": "Missing required fields",
                        "message": "'test_token', 'amount', 'appointment_id', and 'payment_method_types' are required.",
                    },
                    status=status.HTTP_400_BAD_REQUEST,
                )

            # get the appointment
            try:
                appointment = Appointment.objects.get(id=appointment_id)
            except Appointment.DoesNotExist:
                return Response({"error": "Appointment not found."}, status=status.HTTP_404_NOT_FOUND)

            exists = Payment.objects.filter(appointment=appointment_id).exists()

            if not exists:
                # Create a PaymentIntent
                intent = stripe.PaymentIntent.create(
                    amount=int(float(amount) * 100),  # dollars to cents
                    currency="usd",
                    payment_method=test_token,
                    confirm=True,
                    description=description or f"Payment for Appointment {appointment.id}",
                    payment_method_types=payment_method_types,
                    transfer_data={
                        "destination": "acct_1QuBzkPPCNvqJSUB",  # Your connected Stripe Account ID
                    }
                )

                # print(intent, '------------------INTENT')
                # Save payment details
                Payment.objects.create(
                    appointment=appointment,
                    amount=amount,
                    total_amount=amount,
                    method=intent.get("payment_method_types", ["unknown"])[0],
                    status=intent.get("status", "unknown"),
                    payment_notes=intent.get("description"),
                )

                return Response(
                    {
                        "message": "Payment successful!",
                        "payment_intent_id": intent['id'],
                        "status": intent['status'],
                        "payment_method": intent['payment_method'],
                        "payment_method_type": intent['payment_method_types'],
                        "amount": amount,
                        "payment_notes": intent.description,
                        "clientSecret": intent.client_secret,
                        },
                    status=status.HTTP_200_OK,
                )
            else:
                return  Response({'message': "Payment was already made"}, status=status.HTTP_400_BAD_REQUEST)

        except stripe.error.CardError as e:
            return Response(
                {"error": "Card declined", "message": e.user_message},
                status=status.HTTP_400_BAD_REQUEST,
            )
        except Exception as e:
            return Response(
                {"error": "Payment failed", "message": str(e)},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR,
            )

# to create dummy data: Yashvin
# Simulate creating a PaymentIntent (no real payment, just test data)
class CreateDummyData(APIView):
    def post(self, request, *args, **kwargs):
        intent = stripe.PaymentIntent.create(
            amount=10000,  # Amount in cents ($50)
            currency="usd",
            payment_method_types=["card"],
            description="Test PaymentIntent - Simulating Transaction",
        )

        print(intent)
        return  Response({'message','Created'})

# get transactions details
class RetrievePaymentAPIView(APIView):
    def get(self, request, *args, **kwargs):

        try:
            payments = stripe.PaymentIntent.list()
            print(payments)
            return Response({'payments':payments},status=status.HTTP_200_OK)
        except Exception as e:
            return Response({'Error:',f"not found {str(e)}"})


class TransactionHistoryAPIView(APIView):
    """
    API to fetch transaction history and include total, clinic charges, final amount,
    and current balance after clinic charge deductions.
    """

    permission_classes = [IsAuthenticated]

    def get(self, request, *args, **kwargs):
        try:
            # Ensure the logged-in user is a doctor
            if request.user.role != "Doctor":
                return Response(
                    {"error": "You are not authorized to view this information."},
                    status=status.HTTP_403_FORBIDDEN,
                )

            # Fetch the doctor instance linked to the logged-in user
            try:
                doctor = request.user.doctor
            except Doctor.DoesNotExist:
                return Response(
                    {"error": "Doctor profile not found for the current user."},
                    status=status.HTTP_404_NOT_FOUND,
                )

            # Fetch transactions associated with this doctor
            transactions = Payment.objects.filter(
                appointment__doctor=doctor
            ).select_related("appointment", "appointment__patient")

            # Clinic charge deduction
            clinic_charge = 4.8

            # Calculate total balance and current balance
            total_balance = sum([transaction.amount for transaction in transactions])  # Total before deductions
            final_amounts = [float(transaction.amount) - clinic_charge for transaction in transactions]  # After clinic charge deductions
            total_final_amount = sum(final_amounts)  # Final amount after deductions

            # Serialize transactions and apply the clinic charge deduction
            transaction_data = [
                {
                    "sender": f"{transaction.appointment.patient.user.first_name} {transaction.appointment.patient.user.last_name}",
                    "date": transaction.timestamp,
                    "total": float(transaction.amount),  # The total amount from the payment
                    "clinic_charge": clinic_charge,  # The clinic charge field
                    "final_amount": round(float(transaction.amount) - clinic_charge, 2),  # Deduct the clinic charge to get the final amount
                    "description": transaction.payment_notes or f"Payment for Appointment {transaction.appointment.id}",
                    "status": transaction.status,
                }
                for transaction in transactions
            ]

            # response with transactions and balance information
            return Response(
                {
                    "transactions": transaction_data,
                    "total_balance": total_balance,  # The sum of total amounts before deductions
                    "current_balance": total_final_amount,  # The sum of amounts after clinic charge deductions
                },
                status=status.HTTP_200_OK,
            )

        except Exception as e:
            return Response(
                {"error": "An error occurred.", "message": str(e)},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR,
            )

class AddAccountDetailAPIView(APIView):
    """
    API to allow doctors to add their account details.
    Only authenticated doctors can add their own details.
    A doctor can add multiple accounts with unique account numbers.
    """
    permission_classes = [IsAuthenticated]
    def post(self, request, *args, **kwargs):
        # Ensure the user is a doctor
        if not hasattr(request.user, 'doctor'):
            return Response(
                {"error": "Only doctors can add account details."},
                status=status.HTTP_403_FORBIDDEN
            )
        
        # Check if the account already exists
        account_number = request.data.get('account_number')
        account = AccountDetail.objects.filter(user=request.user, account_number=account_number).first()
        
        if account:
            # Create a transaction record for the existing account
            transaction=Transaction.objects.create(
                account=account,
                transaction_type="1",
                amount=request.data.get('amount'),
            )
            transaction_serializer = TransactionSerializer(transaction)
            return Response(
                {
                    "message": "Transaction recorded successfully.",
                    "data": transaction_serializer.data
                    },
                status=status.HTTP_200_OK
            )
        
        # Create a new account if it doesn't exist
        serializer = AccountDetailSerializer(data=request.data)
        if serializer.is_valid():
            account = serializer.save(user=request.user)
            # Optionally create a transaction for the new account
            Transaction.objects.create(
                account=account,
                transaction_type="1",
                amount=request.data.get('amount'),
            )
            return Response(
                {
                    "message": "Account detail added successfully.", 
                    "data": serializer.data
                },
                status=status.HTTP_200_OK
            )
        
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    
    def get(self, request, *args, **kwargs):
        """
        Fetch all account details for the current logged-in doctor.
        """
        # Check if the user is a doctor
        if not hasattr(request.user, 'doctor'):
            return Response(
                {"error": "Only doctors can view their account details."},
                status=status.HTTP_403_FORBIDDEN
            )

        # Fetch all account details for the logged-in doctor
        accounts = AccountDetail.objects.filter(user=request.user)
        serializer = AccountDetailSerializer(accounts, many=True)
        return Response(
            {
                "message": "Account details fetched successfully.",
                "data": serializer.data
            },
            status=status.HTTP_200_OK
        )
import random
import re
from django.conf import settings
from django.utils import timezone
from rest_framework import status
from rest_framework.generics import UpdateAPIView
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework_simplejwt.tokens import RefreshToken
from sendgrid import SendGridAPIClient
from sendgrid.helpers.mail import Mail
from social_core.backends.apple import AppleIdAuth
from social_core.backends.google import GoogleOAuth2
from social_django.utils import load_strategy
from rest_framework.parsers import MultiPartParser, FormParser, JSONParser
from rest_framework.exceptions import AuthenticationFailed

from authify.utils import validate_google_id_token
from users.models import User

from .serializers import (
    OTPVerificationSerializer,
    RegistrationSerializer,
    SignInSerializer,
    SocialLoginSerializer,
    UserProfileUpdateSerializer,
    UserProfileSerializer,
)


def get_tokens_for_user(user):
    """
    Generate refresh and access tokens for the given user.

    Args:
        user (User): The user instance for which tokens are generated.

    Returns:
        dict: A dictionary containing 'refresh' and 'access' tokens.
    """
    refresh = RefreshToken.for_user(user)
    return {
        "refresh": str(refresh),
        "access": str(refresh.access_token),
    }


class SignUpView(APIView):
    """
    API view for user sign-up.
    Handles the registration of a new user by validating the provided data
    and creating a new user instance.
    """

    def generate_otp(self):
        """
        Generate a 6-digit OTP.
        """
        return str(random.randint(100000, 999999))

    def send_otp_email(self, email, otp):
        """
        Send the OTP to the user's email via SendGrid.
        """
        message = Mail(
            from_email=settings.SENDGRID_FROM_EMAIL,
            to_emails=email,
            subject="Your OTP Code",
            plain_text_content=f"Your OTP code is {otp}",
        )

        try:
            sg = SendGridAPIClient(settings.SENDGRID_API_KEY)
            response = sg.send(message)
            return response
        except Exception as e:
            print(str(e), 'sign in........')

    def post(self, request, *args, **kwargs):
        serializer = RegistrationSerializer(data=request.data)
        if serializer.is_valid():
            user = serializer.save()

            # Generate OTP
            otp = self.generate_otp()

            # Send OTP to user's email
            email_response = self.send_otp_email(user.email, otp)

            if isinstance(email_response, str):
                return Response(
                    {"message": f"Failed to send OTP: {email_response}"},
                    status=status.HTTP_500_INTERNAL_SERVER_ERROR,
                )

            # Store OTP in the database for verification later
            user.otp = otp
            user.save()

            return Response(
                {
                    "message": "User registered successfully. OTP sent to your email.",
                    "user": serializer.data,
                },
                status=status.HTTP_201_CREATED,
            )
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class OTPVerificationView(APIView):
    """
    API view to verify OTP for the given user using email and OTP.
    """

    def post(self, request, *args, **kwargs):
        serializer = OTPVerificationSerializer(data=request.data)
        if serializer.is_valid():
            email = serializer.validated_data["email"]
            otp = serializer.validated_data["otp"]

            # Retrieve user by email
            try:
                user = User.objects.get(email=email)
            except User.DoesNotExist:
                return Response(
                    {"message": "User not found."},
                    status=status.HTTP_404_NOT_FOUND,
                )

            # Check if OTP matches
            if user.otp != otp:
                return Response(
                    {"message": "Invalid OTP."},
                    status=status.HTTP_400_BAD_REQUEST,
                )

            # OTP expired (e.g., 5 minutes from `date_joined` or OTP timestamp)
            otp_timestamp = user.date_joined  # OTP sent when user is created
            if (timezone.now() - otp_timestamp).total_seconds() > 300:
                return Response(
                    {"message": "OTP has expired. Please request a new one."},
                    status=status.HTTP_400_BAD_REQUEST,
                )

            # OTP is valid, verify the user's account
            user.is_verified = True
            user.save()

            # Generate JWT tokens after OTP verification
            tokens = get_tokens_for_user(user)

            return Response(
                {
                    "message": "OTP verified successfully!",
                    "tokens": tokens,
                },
                status=status.HTTP_200_OK,
            )

        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class SignInView(APIView):
    """
    API view for user sign-in and account activation.
    """

    def post(self, request, *args, **kwargs):
        serializer = SignInSerializer(data=request.data)
        if serializer.is_valid():
            print(serializer)
            user = serializer.validated_data["user"]
            print(serializer.validated_data)

            # Generate JWT tokens
            tokens = get_tokens_for_user(user)
            return Response(
                {
                    "message": "Login successful.",
                    "user": {
                        "id": user.id,
                        "email": user.email,
                        "first_name": user.first_name,
                        "last_name": user.last_name,
                        "role": user.role,
                        "is_verified": user.is_verified,
                    },
                    "tokens": tokens,
                },
                status=status.HTTP_200_OK,
            )
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class ForgotPasswordView(APIView):
    """
    API view for handling forgot password requests.
    Generates an OTP and sends it to the user's registered email for verification.
    """

    def generate_otp(self):
        """
        Generate a 6-digit OTP.
        """
        return str(random.randint(100000, 999999))

    def send_otp_email(self, email, otp):
        """
        Send the OTP to the user's email using SendGrid.
        """
        message = Mail(
            from_email=settings.SENDGRID_FROM_EMAIL,
            to_emails=email,
            subject="Password Reset OTP",
            plain_text_content=f"Your OTP for password reset is {otp}. It is valid for 10 minutes.",
        )

        try:
            sg = SendGridAPIClient(settings.SENDGRID_API_KEY)
            response = sg.send(message)
            return response
        except Exception as e:
            return str(e)

    def post(self, request, *args, **kwargs):
        """
        Handle forgot password request.
        """
        email = request.data.get("email")
        # Check if user exists with the provided email
        try:
            user = User.objects.get(email=email)
        except User.DoesNotExist:
            return Response(
                {"message": "No user found with this email."},
                status=status.HTTP_404_NOT_FOUND,
            )

        # Generate and send OTP
        otp = self.generate_otp()
        email_response = self.send_otp_email(email, otp)
        if isinstance(email_response, str):
            return Response(
                {"message": f"Failed to send OTP: {email_response}"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR,
            )

        # Store OTP in user's model
        user.otp = otp  # Custom User model with 'otp' field
        user.save()
        return Response(
            {"message": "OTP sent successfully to your email."},
            status=status.HTTP_200_OK,
        )


class VerifyEmailAndGenerateTokensView(APIView):
    """
    API view to verify email using OTP and generate access and refresh tokens.
    """

    def post(self, request, *args, **kwargs):
        """
        Verify OTP and email, then generate access and refresh tokens.
        """
        email = request.data.get("email", "").lower().strip()
        otp = request.data.get("otp")

        # Validate input fields
        if not all([email, otp]):
            return Response(
                {"message": "Email and OTP are required."},
                status=status.HTTP_400_BAD_REQUEST,
            )

        # get the user
        try:
            user = User.objects.get(email=email)
        except User.DoesNotExist:
            return Response(
                {"message": "Invalid email or OTP."},
                status=status.HTTP_400_BAD_REQUEST,
            )

        # Check if OTP matches
        if user.otp != otp:
            return Response(
                {"message": "Invalid email or OTP."},
                status=status.HTTP_400_BAD_REQUEST,
            )

        # Clear OTP after successful verification
        user.otp = None
        user.save()

        # Generate access and refresh tokens
        refresh = RefreshToken.for_user(user)
        access_token = str(refresh.access_token)

        return Response(
            {
                "message": "Email verified successfully.",
                "access_token": access_token,
                "refresh_token": str(refresh),
            },
            status=status.HTTP_200_OK,
        )


class ChangePasswordView(APIView):
    """
    API view for changing the password after email verification.
    """

    permission_classes = [IsAuthenticated]

    def post(self, request, *args, **kwargs):
        """
        Change the password for the authenticated user.
        """
        current_password = request.data.get("current_password")
        new_password = request.data.get("new_password")
        # Validate the provided data
        if not current_password or not new_password:
            return Response(
                {"message": "Current password and new password are required."},
                status=status.HTTP_400_BAD_REQUEST,
            )

        # Password strength validation: 8+ characters, mix of letters, numbers, and symbols
        if len(new_password) < 8:
            return Response(
                {"message": "New password must be at least 8 characters long."},
                status=status.HTTP_400_BAD_REQUEST,
            )
        if not re.search(r'[A-Za-z]', new_password):
            return Response(
                {"message": "New password must contain at least one letter."},
                status=status.HTTP_400_BAD_REQUEST,
            )
        if not re.search(r'[0-9]', new_password):
            return Response(
                {"message": "New password must contain at least one number."},
                status=status.HTTP_400_BAD_REQUEST,
            )
        if not re.search(r'[@$!%*?&]', new_password):
            return Response(
                {"message": "New password must contain at least one special character (e.g., @$!%*?&)."},
                status=status.HTTP_400_BAD_REQUEST,
            )
        # Get the authenticated user
        user = request.user

        # Check if the current password matches
        if not user.check_password(current_password):
            return Response(
                {"message": "Current password is incorrect."},
                status=status.HTTP_400_BAD_REQUEST,
            )
        # Change the user's password
        user.set_password(new_password)
        user.save()

        return Response(
            {"message": "Password changed successfully."},
            status=status.HTTP_200_OK,
        )


class AccountDeactivateDeleteView(APIView):
    """
    API view to deactivate the user's account.
    """

    permission_classes = [IsAuthenticated]
    def post(self, request, *args, **kwargs):
        """
        Deactivate the authenticated user's account.
        """
        # Get the authenticated user
        user = request.user

        # Deactivate the account
        user.is_active = False
        user.save()

        return Response(
            {"message": "Account deactivated successfully."},
            status=status.HTTP_200_OK,
        )
        
    def delete(self, request, *args, **kwargs):
        """
        Delete the authenticated user's account (Doctor) and all related data:
        Appointments, Consultation Summaries, Prescriptions, Doctor's Notes,
        Account Details, Transactions, Reviews, Education, Media, Skills, and the User itself.
        """
        user = request.user

        try:
            # Check if the logged-in user is a doctor
            if user.role != "Doctor":
                return Response(
                    {"message": "You are not authorized to perform this action."},
                    status=status.HTTP_403_FORBIDDEN,
                )

            # Delete related data if the user is a doctor
            if hasattr(user, 'doctor'):
                doctor = user.doctor

                # 1. Delete appointments and related data
                if hasattr(doctor, 'appointments'):
                    appointments = doctor.appointments.all()
                    for appointment in appointments:
                        # Delete consultation summaries, prescriptions, and doctor's notes related to the appointment
                        if hasattr(appointment, 'consultation_summary'):
                            appointment.consultation_summary.delete()
                        if hasattr(appointment, 'prescriptions'):
                            appointment.prescriptions.all().delete()
                        if hasattr(appointment, 'doctors_notes'):
                            appointment.doctors_notes.all().delete()

                        # Finally, delete the appointment
                        appointment.delete()

                # 2. Delete doctor's account details
                if hasattr(doctor, 'account_details'):
                    doctor.account_details.all().delete()

                # 3. Delete transactions related to the doctor
                if hasattr(doctor, 'transactions'):
                    doctor.transactions.all().delete()

                # 4. Delete reviews written for the doctor
                if hasattr(doctor, 'reviews'):
                    doctor.reviews.all().delete()

                # 5. Delete education, media, and skills
                if hasattr(doctor, 'education'):
                    doctor.education.all().delete()
                if hasattr(doctor, 'media'):
                    doctor.media.all().delete()
                if hasattr(doctor, 'skills'):
                    doctor.skills.clear()  # ManyToMany field, clear it

                # 6. Finally, delete the Doctor object
                doctor.delete()

            # Delete the user
            user.delete()

            return Response(
                {"message": "Doctor account and all related data deleted successfully."},
                status=status.HTTP_204_NO_CONTENT,
            )
        except Exception as e:
            return Response(
                {"message": f"Error deleting account: {str(e)}"},
                status=status.HTTP_400_BAD_REQUEST,
            )
                
            
class ResendOTPView(APIView):
    """
    API view for resending an OTP if the previous OTP has expired or is invalid.
    """

    def generate_otp(self):
        """
        Generate a 6-digit OTP.
        """
        return str(random.randint(100000, 999999))

    def send_otp_email(self, email, otp):
        """
        Send the OTP to the user's email using SendGrid.
        """
        message = Mail(
            from_email=settings.SENDGRID_FROM_EMAIL,
            to_emails=email,
            subject="Password Reset OTP - Resend",
            plain_text_content=f"Your new OTP for password reset is {otp}. It is valid for 10 minutes.",
        )

        try:
            sg = SendGridAPIClient(settings.SENDGRID_API_KEY)
            response = sg.send(message)
            return response
        except Exception as e:
            return str(e)

    def post(self, request, *args, **kwargs):
        """
        Handle resend OTP request.
        """
        email = request.data.get("email")

        # Check if user exists with the provided email
        try:
            user = User.objects.get(email=email)
        except User.DoesNotExist:
            return Response(
                {"message": "No user found with this email."},
                status=status.HTTP_404_NOT_FOUND,
            )

        # Generate and send a new OTP
        new_otp = self.generate_otp()
        email_response = self.send_otp_email(email, new_otp)

        if isinstance(email_response, str):
            return Response(
                {"message": f"Failed to resend OTP: {email_response}"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR,
            )

        # Update the user's OTP in the database
        user.otp = new_otp
        user.save()

        return Response(
            {"message": "A new OTP has been sent successfully to your email."},
            status=status.HTTP_200_OK,
        )


class GoogleLoginView(APIView):
    """
    API view for Google-based authentication.
    Handles login or registration using a Google OAuth2 token.
    """

    def post(self, request):
        """
        Handles POST requests for Google login.

        Args:
            request (Request): The HTTP request containing the Google OAuth2 token.

        Returns:
            Response: A success message and a JWT token on successful authentication, or an error on failure.
        """
        try:
            # Use the SocialLoginSerializer to validate the role and token
            social_login_serializer = SocialLoginSerializer(data=request.data)

            if not social_login_serializer.is_valid():
                return Response(
                    social_login_serializer.errors, status=status.HTTP_400_BAD_REQUEST
                )

            token = request.data.get("token")
            client_id = "853181483027-b3pgc8d9m5vq2l83f4hu10mu5se690gi.apps.googleusercontent.com"

            if not token:
                return Response(
                    {"error": "Token is required"}, status=status.HTTP_400_BAD_REQUEST
                )

            # Validate the Google token
            validation_result = validate_google_id_token(token, client_id)
            if validation_result["status"] == "valid":
                user_info = validation_result["user_info"]

                # Extract user information from the token
                email = user_info.get("email")
                full_name = user_info.get("name", "")
                first_name = user_info.get("given_name", "")
                last_name = user_info.get("family_name", "")
                role = request.data.get("role", None)
                # Fallback to parsing the full name if first_name or last_name is missing
                if not first_name or not last_name:
                    name_parts = full_name.split()
                    first_name = name_parts[0] if name_parts else ""
                    last_name = " ".join(name_parts[1:]) if len(name_parts) > 1 else ""

                # Retrieve or create the user based on the email
                user, created = User.objects.get_or_create(
                    email=email,
                )
                if created:
                    user.first_name = first_name
                    user.last_name = last_name
                    if role:
                        user.role = role
                    user.save()

                # Generate JWT tokens for the user
                token = get_tokens_for_user(user)

                return Response(
                    {
                        "message": "Login successful",
                        "token": token,
                    },
                    status=status.HTTP_200_OK,
                )

            elif validation_result["status"] == "expired":
                return Response(
                    {"error": "Token is expired"}, status=status.HTTP_400_BAD_REQUEST
                )
            else:
                return Response(
                    {"error": validation_result["message"]},
                    status=status.HTTP_400_BAD_REQUEST,
                )

        except Exception as e:
            return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)


class AppleLoginView(APIView):
    """
    API view for Apple-based authentication.
    Handles login or registration using an Apple ID token.
    """

    def post(self, request):
        """
        Handles POST requests for Apple login.

        Args:
            request (Request): The HTTP request containing the Apple ID token.

        Returns:
            Response: A success message and a JWT token on successful authentication, or an error on failure.
        """
        strategy = load_strategy(request)  # Load the social authentication strategy
        token = request.data.get("token")  # Get the Apple ID token from the request

        try:
            # Use the Apple ID backend to authenticate the user
            backend = AppleIdAuth(strategy=strategy)
            user = backend.do_auth(token)
            if user:
                # Generate tokens for the authenticated user
                token = get_tokens_for_user(user)
                return Response(
                    {"message": "Login successful", "token": token},
                    status=status.HTTP_200_OK,
                )
            # Return error if authentication fails
            return Response(
                {"error": "Authentication failed"}, status=status.HTTP_400_BAD_REQUEST
            )
        except Exception as e:
            # Catch and return any exceptions that occur
            return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)


class UpdateUserProfileAPIView(APIView):
    permission_classes = [IsAuthenticated]
    parser_classes = [MultiPartParser, FormParser, JSONParser]

    def patch(self, request):
        serializer = UserProfileUpdateSerializer(instance=request.user, data=request.data, partial=True)
        if serializer.is_valid():
            user = serializer.save()
            user_data = {
                "first_name": user.first_name,
                "last_name": user.last_name,
                "dob": user.dob,
                "gender": user.gender,
                "phone_number": user.phone_number,
                "bio": user.bio,
                "country": user.country,
                "city": user.city,
                "languages": user.languages,
                "work_place": user.work_place,
                "expertise": user.expertise,
                "professional_stat": user.professional_stat,
                "working_time": user.working_time,
                "profile_picture": user.profile_picture.url if user.profile_picture else None
            }
            return Response({"message": "Profile updated successfully.", "data": user_data}, status=status.HTTP_200_OK)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)



class GetUserProfileAPIView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        try:
            if not request.user.is_authenticated:
                raise AuthenticationFailed("User is not authenticated.")
            
            user = request.user
            role = user.role

            # Handle case where the role is missing or invalid
            if not role:
                return Response({"message": "User role is not assigned."}, status=status.HTTP_400_BAD_REQUEST)

            # Role-based response logic
            if role == 'Patient':
                serializer = UserProfileSerializer(user)
                data = serializer.data
                return Response({"message": "Patient profile.", "data": data}, status=status.HTTP_200_OK)
            elif role == 'Doctor':
                serializer = UserProfileSerializer(user)
                data = serializer.data
                return Response({"message": "Doctor profile.", "data": data}, status=status.HTTP_200_OK)
            else:
                return Response({"message": "Invalid role assigned to user."}, status=status.HTTP_400_BAD_REQUEST)

        except AuthenticationFailed as e:
            # Handle case where user is not authenticated
            return Response({"message": str(e)}, status=status.HTTP_401_UNAUTHORIZED)

        except Exception as e:
            # Catch any other unexpected errors
            return Response({"message": f"An unexpected error occurred: {str(e)}"}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

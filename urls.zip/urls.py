from django.urls import path
from .views import fitbit_login, fitbit_callback, home, dashboard

# urlpatterns = [
#     path('home/', home, name='home'),
#     path('dashboard/', dashboard, name='dashboard'),
#     path("oauth/login/", fitbit_login, name="fitbit_login"),
#     path("oauth/callback/", fitbit_callback, name="fitbit_callback"),
# ]

from . import v
urlpatterns = [
    path('login/', v.fitbit_login, name='home'),
    path('dashboard/', v.dashboard, name='dashboard'),
    path("oauth/callback/", v.fitbit_callback, name="fitbit_callback"),
]
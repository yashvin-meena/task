from django.shortcuts import redirect
import requests
import base64
from django.conf import settings
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
from django.shortcuts import render

def home(request):
    return render(request,'login.html')

def fitbit_login(request):
    auth_url = (
       "https://www.fitbit.com/oauth2/authorize?response_type=code&client_id=23Q7RT&redirect_uri=http%3A%2F%2F127.0.0.1%3A8000%2Foauth%2Fcallback%2F&scope=activity%20heartrate"


    )
    return redirect(auth_url)

FITBIT_API_URL = "https://api.fitbit.com/1/user/-/activities/heart/date/today/1d.json"
def dashboard(request):
    """Fetch Fitbit data and display on dashboard"""
    access_token = request.session.get("fitbit_access_token")
    
    if not access_token:
        return render(request, "dashboard.html", {"error": "Fitbit not connected"})

    headers = {"Authorization": f"Bearer {access_token}"}
    response = requests.get(FITBIT_API_URL, headers=headers)

    if response.status_code == 200:
        fitbit_data = response.json()
        print('Fitbit data:',response.json())
        return render(request, "dashboard.html", {"fitbit_data": fitbit_data})
    
    return render(request, "dashboard.html", {"error": "Failed to fetch Fitbit data"})


FITBIT_TOKEN_URL = "https://api.fitbit.com/oauth2/token"

def fitbit_callback(request):
    """Handle Fitbit OAuth callback"""
    code = request.GET.get("code")  # Get authorization code
    if not code:
        print(" No code received")
        return redirect("/")

    #  Encode client_id and client_secret in Base64 for Basic Auth
    client_credentials = f"{settings.FITBIT_CLIENT_ID}:{settings.FITBIT_CLIENT_SECRET}"
    encoded_credentials = base64.b64encode(client_credentials.encode()).decode()

    #  Prepare headers and data for token request
    headers = {
        "Authorization": f"Basic {encoded_credentials}",
        "Content-Type": "application/x-www-form-urlencoded",
    }
    data = {
        "code": code,
        "grant_type": "authorization_code",
        "redirect_uri": settings.FITBIT_REDIRECT_URI,
    }

    #  Send request to Fitbit
    response = requests.post(FITBIT_TOKEN_URL, headers=headers, data=data)

    print("Fitbit Response:", response.status_code, response.text)  #  Debugging line

    #  If successful, get access token
    if response.status_code == 200:
        token_data = response.json()
        access_token = token_data.get("access_token")

        request.session["fitbit_access_token"] = access_token  # Store in session
        return redirect("/dashboard/")
    
    return redirect("/")
